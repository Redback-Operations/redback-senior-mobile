import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html, Input, Output

# Load vaccination data
vacc = pd.read_csv("covid-19-vaccine-doses-administered-per-100-people (2).csv")
vacc.columns = vacc.columns.str.strip()

if "Day" in vacc.columns:
    vacc.rename(columns={"Day": "Date"}, inplace=True)

vacc["Date"] = pd.to_datetime(vacc["Date"], errors="coerce")

vacc_id_vars = [col for col in ["Entity", "Date"] if col in vacc.columns]
vacc_long = vacc.melt(id_vars=vacc_id_vars, var_name="Metric", value_name="Value")

# Load deaths data
deaths = pd.read_csv("daily-new-confirmed-covid-19-deaths-per-million-people (2).csv")
deaths.columns = deaths.columns.str.strip()

if "Day" in deaths.columns:
    deaths.rename(columns={"Day": "Date"}, inplace=True)

deaths["Date"] = pd.to_datetime(deaths["Date"], errors="coerce")

deaths_id_vars = [col for col in ["Entity", "Date"] if col in deaths.columns]
deaths_long = deaths.melt(id_vars=deaths_id_vars, var_name="Metric", value_name="Value")

# Focus countries
focus_countries = ["United States", "Chile", "Portugal", "Australia", "China"]

# Dash app
app = Dash(__name__)

app.layout = html.Div([
    html.H1("COVID-19 Dashboard", style={"textAlign": "center"}),

    dcc.Dropdown(
        id="country-dropdown",
        options=[{"label": c, "value": c} for c in focus_countries],
        value="Australia",
        multi=False,
        style={"width": "50%", "margin": "auto"}
    ),

    html.Div(id="summary-cards", style={"display": "flex", "gap": "20px", "justifyContent": "center", "margin": "20px"}),

    dcc.Graph(id="vaccination-graph"),
    dcc.Graph(id="deaths-graph"),

    html.Div(id="insights-box", style={
        "margin": "20px auto",
        "padding": "20px",
        "width": "80%",
        "border": "1px solid #ccc",
        "borderRadius": "10px",
        "backgroundColor": "#f9f9f9",
        "textAlign": "center",
        "fontSize": "16px"
    })
])

@app.callback(
    [Output("summary-cards", "children"),
     Output("vaccination-graph", "figure"),
     Output("deaths-graph", "figure"),
     Output("insights-box", "children")],
    [Input("country-dropdown", "value")]
)
def update_dashboard(selected_country):
    # Vaccination data
    vacc_country = vacc_long[vacc_long["Entity"] == selected_country].dropna(subset=["Value"])
    deaths_country = deaths_long[deaths_long["Entity"] == selected_country].dropna(subset=["Value"])

    # Latest stats
    latest_vacc = vacc_country.sort_values("Date").iloc[-1] if not vacc_country.empty else None
    latest_death = deaths_country.sort_values("Date").iloc[-1] if not deaths_country.empty else None

    cards = []
    if latest_vacc is not None:
        cards.append(html.Div([
            html.H4("Latest Vaccinations per 100 people"),
            html.P(f"{latest_vacc['Value']:.2f} on {latest_vacc['Date'].date()}")
        ], style={"padding": "10px", "border": "1px solid #ccc", "borderRadius": "10px", "flex": "1", "textAlign": "center"}))

    if latest_death is not None:
        cards.append(html.Div([
            html.H4("Latest Deaths per million"),
            html.P(f"{latest_death['Value']:.2f} on {latest_death['Date'].date()}")
        ], style={"padding": "10px", "border": "1px solid #ccc", "borderRadius": "10px", "flex": "1", "textAlign": "center"}))

    # Graphs
    vacc_fig = px.line(
        vacc_country, x="Date", y="Value", color="Metric",
        title=f"Vaccinations in {selected_country}"
    )

    deaths_fig = px.line(
        deaths_country, x="Date", y="Value", color="Metric",
        title=f"COVID-19 Deaths per Million in {selected_country}"
    )

    # Generate dynamic insights
    insight_text = f"Insights for {selected_country}: "
    if latest_vacc is not None:
        if latest_vacc["Value"] > 90:
            insight_text += f"{selected_country} has achieved very high vaccination coverage (>90 per 100 people). "
        elif latest_vacc["Value"] > 50:
            insight_text += f"Vaccination rates are strong, covering more than half the population. "
        else:
            insight_text += f"Vaccination rates remain relatively low compared to other countries. "

    if latest_death is not None:
        peak_death = deaths_country.loc[deaths_country["Value"].idxmax()]
        insight_text += f"The highest death rate was {peak_death['Value']:.2f} deaths per million on {peak_death['Date'].date()}. "
        if latest_death["Value"] < 1:
            insight_text += "Currently, deaths are very low, suggesting good control over the pandemic."
        else:
            insight_text += "Deaths are still being reported, indicating ongoing challenges."

    return cards, vacc_fig, deaths_fig, insight_text


if __name__ == "__main__":
    app.run()
